Run python3 -B boundary-mixtures/astra_check.py and python3 -B boundary-mixtures/certificate.py from this directory. Python 3 standard library only.

Run python3 -BIu review_margins.py for the revised geometric tail and alphabet units.
