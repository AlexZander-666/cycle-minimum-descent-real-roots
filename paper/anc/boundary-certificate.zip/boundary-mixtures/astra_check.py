"""Independent boundary-row check using the exact alphabet values q<=n only."""
import json
from fractions import Fraction as F
from itertools import permutations
from math import comb, factorial
from pathlib import Path

mesh = json.loads((Path(__file__).resolve().parents[1]/'finite-127/certificate.json').read_text())['mesh']


def reconstruct(n, derange):
    counts = []
    for q in range(1,n+1):
        labels = q**(n-q)*(q-1)**q if derange else q**n
        counts.append(labels - sum(c*comb(q+n-1-i,n) for i,c in enumerate(counts)))
    assert min(counts) >= 0
    return counts


def numerator(c, a, shift):
    num = 0
    for i in reversed(range(len(c))):
        num = a*num + (c[i] << (shift*(len(c)-1-i)))
    return num


def source(n):
    counts = [[0]*n for k in range(n)]
    for w in permutations(range(n)):
        left = set(range(n))
        least = n
        while left:
            i = next(iter(left))
            length = 0
            while i in left:
                left.remove(i); length += 1; i = w[i]
            least = min(least,length)
        r = sum(a>b for a,b in zip(w,w[1:]))
        for k in range(least):
            counts[k][r] += 1
    return counts


def finite():
    total = 0
    for n in range(1,128):
        a = reconstruct(n,False); b = reconstruct(n,True)
        if n<=8:
            raw=source(n)
            assert a==raw[0]
            if n>=2:assert b==raw[1]
        if n in (4,5):
            nodes=[(-1,1),(-2,0)] if n==4 else [(-1,2),(-1,0),(-4,0)]
            table=[[numerator(c,x,h) for x,h in nodes] for c in raw]
            print('n=',n,'all raw rows at replacement nodes, after positive denominator clearing:',table)
            assert b==([0,4,4,1] if n==4 else [0,8,24,12,0])
            if n==5:assert all(c==[0,6,12,6,0] for c in raw[2:])
        elif n>=3:
            nodes=mesh[str(n)]
            assert len(nodes)==n-2
            vals=[F(x,2**h) for x,h in nodes]
            assert all(v<0 for v in vals) and all(x>y for x,y in zip(vals,vals[1:]))
            for i,(x,h) in enumerate(nodes,2):
                for c in (a,b):
                    assert (-1)**(i-1)*numerator(c,x,h)>0
                    total+=1
    assert total==15740
    print('Original permutation rows through eight and all',total,'new common-node signs passed.')


def exp_upper(x):
    # The ratios starting at degree two are at most x/3.
    return 1+x+x*x/2/(1-x/3)


def budget():
    tail=F(15)*F(4,5)**128
    assert 6**3<15**2 and tail<F(1,10**10)
    # Alternating partial sums of e^(-1) also contain p_n for n>=128.
    lo=sum(F((-1)**j,factorial(j)) for j in range(10))
    hi=sum(F((-1)**j,factorial(j)) for j in range(11))
    assert F(3678,10000)<lo<hi<F(3680,10000)
    for v,ceiling in [(F(3,8),F(3,7)),(F(1,2),2),(F(2,3),3)]:
        s=v/(2*(1-v))
        assert (hi*(exp_upper(s)-1)+tail)/lo < ceiling
    for m, lower, upper in [(4,F(6,7),F(8,7)),(3,F(2,3),F(4,3))]:
        assert (F(m-1,m)**m-tail)/hi > lower
        assert (F(m,m+1)**m+tail)/lo < upper
    for eta,i in [(F(1,4),5),(F(1,32),4)]:
        assert F(8,7)*F(2,3)+F(1,2)*eta**(i-3)+3*eta**(i-2)+3*eta**(i-1)<F(6,7)
    assert F(6,99)<F(2,3)
    assert F(1,4)-tail>F(1,256)
    print('All rational tail, derivative-free Taylor mass and outer-node margins passed.')


if __name__=='__main__':
    finite()
    budget()
