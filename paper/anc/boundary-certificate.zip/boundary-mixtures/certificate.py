"""Check Eulerian and derangement additions on the published finite long-cycle mesh."""
from hashlib import sha256
from itertools import permutations
from math import comb, factorial
from pathlib import Path
import json
import runpy

ROOT = Path(__file__).resolve().parents[1] / "finite-127"
methods = runpy.run_path(str(ROOT / "certify.py"))
data = json.loads((ROOT / "certificate.json").read_text())
stored = {c["n"]: c for c in data["cases"] if c["k"] == 2}


def eulerian(row):
    return [(r+1)*(row[r] if r < len(row) else 0)
            + (len(row)+1-r)*(row[r-1] if r else 0) for r in range(len(row)+1)]


def derangement(n):
    words = [sum((-1)**j * comb(q,j) * q**(n-j) for j in range(min(n,q)+1))
             for q in range(1,n+3)]
    co = methods["trim"](methods["ordinary_row"](n, words))
    actual = sha256(",".join(map(str,co)).encode("ascii")).hexdigest()
    assert actual == stored[n]["coefficient_sha256"]
    return co


def at(row, rational):
    return methods["sign_at"](row, rational)


def literal(n, k):
    row = [0]*n
    for w in permutations(range(n)):
        seen = set()
        sizes = []
        for j in range(n):
            if j not in seen:
                size = 0
                while j not in seen:
                    seen.add(j)
                    j = w[j]
                    size += 1
                sizes.append(size)
        if min(sizes) >= k:
            row[sum(a>b for a,b in zip(w,w[1:]))] += 1
    return methods["trim"](row)


def main():
    count = 0
    A = [1]
    for n in range(2,128):
        A = eulerian(A)
        assert len(A) == n and sum(A) == factorial(n)
        B = derangement(n)
        if n <= 8:
            assert literal(n,1) == A and literal(n,2) == B
        if n < 3:
            continue
        if n in (4,5):
            points = [(-1,1),(-2,0)] if n == 4 else [(-1,2),(-1,0),(-4,0)]
            signs = [[at(literal(n,k), t) for t in points] for k in range(1,n+1)]
            expected = [[-1,1], [-1,0], [-1,1], [-1,1]] if n == 4 else [
                [-1,1,-1], [-1,1,-1], *([[-1,0,-1]]*3)]
            assert signs == expected, (n, signs)
            print(n, points, signs)
            continue
        for i,node in enumerate(data["mesh"][str(n)],2):
            expected = 1 if i%2 else -1
            assert at(A, node) == expected and at(B, node) == expected, (n,i)
            count += 2
    print(f"PASS {count} strict common signs for the two boundary families on the original nodes.")
    print("PASS exceptional weak nodes at n=4,5; literal original permutations through 8.")


if __name__ == "__main__":
    main()

