"""Exact rational checks of the revised tail budget, orientations and exceptional polynomials."""
from fractions import Fraction as F
from math import comb, factorial

eta = F(1, 5)
truncated = sum(F(5, 3)**j/factorial(j) for j in range(5))
assert -2+F(1,4)+F(1,32) == -F(55,32) < -F(5,3)
assert truncated == F(10009,1944) > 5
usual = F(8,7)*(eta/(1-eta)+F(1,4)/(1-F(1,4)))
excess = F(4,21)*eta + F(13,7)*(eta**2+eta**3)
assert usual == F(2,3) and usual+excess == F(2084,2625)
assert F(6,7)-usual-excess == F(166,2625)
assert 15*F(4,5)**128 < F(6,10**12) < F(1,10**10)
for n in range(2,129):
    for q in (1,2):
        forward = sum((-1)**j*comb(q,j)*q**(n-j) for j in range(min(q,n)+1))
        reverse = sum((-1)**j*comb(q+j-1,j)*q**(n-j) for j in range(n+1))
        if q == 1:
            assert (forward,reverse) == (0,int(n%2 == 0))
        if q == 2 and n == 128:
            pn = sum(F((-1)**j, factorial(j)) for j in range(n+1))
            for g in (forward,reverse):
                assert F(g,2**n) > F(1,2*n)
                assert F(g,2**n)/pn == F(g,1)/(pn*2**n)
print("PASS exact 1/5 ratio, 2084/2625 tail, 166/2625 margin, both q=1 parities and q=2 units.")
