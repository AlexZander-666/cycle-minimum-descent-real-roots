Python 3.12; standard library only. From the extracted root run:
sha256sum -c SHA256SUMS
python3 -BIu finite-127/certify.py --last 127 --direct 9 --verify finite-127/certificate.json
python3 -BIu shared-angle-mesh/verify.py finite-127
python3 -BIu check_margins.py
