"""Exact rational endpoint margins in the single-cycle and all-cutoff arguments."""
from fractions import Fraction as Q
from math import factorial

def exp_lower(x, degree):
    return sum(Q(x)**j / factorial(j) for j in range(degree+1))

assert (Q(11,4)*Q(22,7))**2*Q(65,2*64**2) < Q(39,50)**2
assert Q(22,7)**2 * Q(65,16*64) < 1
assert 1024*Q(39,50)**32 < Q(1,2)
assert Q(65,64)**3*Q(39,50)<1
assert Q(1,16)-(4-Q(1,16))*Q(4,5)/2 == -Q(121,80)
assert exp_lower(Q(3,2),4)>4
assert Q(5,6)>Q(7,6)*Q(2,3)
u=Q(1,4)
assert 2*u**2/(1-u)+u**3/((1-u)*(1-u**3)) < Q(1,5)
assert Q(5,2)*(8+Q(3,4)/(1-u**3))/(1-u)<30
assert (Q(11,4)*Q(22,7))**2*Q(8193,2*8192)<49
n=8192
assert Q(49,n)<Q(1,8)**2
assert Q(1,4)+Q(2205,n)+Q(2*n,2**(n//2)) < 1
assert exp_lower(Q(n,480)-Q(1,2),28)>8*n
assert exp_lower(Q(n,512)-1,30)>Q(64*n,3)
assert all(Q(i-15,i*i)>=Q(1,256) for i in range(16,24))
assert Q(16,3)*24**2/4**8 < Q(1,8)
print('PASS rational endpoint bounds for n>=64 and the global n>=8192 cutoff proposition.')

def J(v):
    return (v*v/3+v*v/4+v**4/5+(v**3+v**4+v**5)/6+v**6/7+
            v**4/(1-v)+v**3/(2*(1-v)*(1-v**3)))

assert J(Q(2,3))<2 and Q(11,4)**2 < 8
n=128
assert 16*n*Q(3,4)**64 < Q(1,1000)
assert (Q(129,128)**4 * Q(3,4)) < 1
for v,cap in [(Q(1,4),Q(1,7)),(Q(1,3),Q(1,3)),(Q(3,8),Q(3,7)),(Q(1,2),2)]:
    j=J(v)
    assert j<1 and 2*j/(1-j)+Q(1,1000) < cap
assert Q(22,7)**2/(24*129)<Q(1,200)
assert Q(400,199)**2*Q(129,128)<Q(41,20)**2
assert (2*Q(41,20))**2/n<Q(3,8)**2 and (Q(11,4)*Q(41,20))**2/n<Q(1,2)**2
assert 16*n*n*Q(3,4)**64 < Q(1,100)
assert Q(1,4)+Q(9,14)+Q(1,100)<1
assert Q(5,64) < Q(6,7)-Q(8,7)*Q(2,3)
assert exp_lower(Q(15,4),8)>32 and exp_lower(5,9)>100
assert exp_lower(Q(128,12)-Q(1,2),12)>8*n
print('PASS all-cutoffs endpoint n>=128, with distinct residual and true-reflection margins.')
