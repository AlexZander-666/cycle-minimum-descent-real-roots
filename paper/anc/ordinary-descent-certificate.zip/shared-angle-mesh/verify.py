from argparse import ArgumentParser
from collections import Counter
import json
from pathlib import Path
import runpy

parser = ArgumentParser(description="Check the common negative intervals at every specified size.")
parser.add_argument("certificate_directory", type=Path)
parser.add_argument("--last", type=int, default=127)
args = parser.parse_args()
root = args.certificate_directory.resolve()
data = json.loads((root / "certificate.json").read_text())
if data["last"] != args.last or args.last < 3:
    raise ValueError("The certificate does not cover the requested final size.")
methods = runpy.run_path(str(root / "certify.py"))
counts = methods["word_counts"](data["last"])
nonalternating = []
checked = 0
for n in range(3, data["last"] + 1):
    if n == 5:
        continue
    nodes = data["mesh"][str(n)]
    if len(nodes) != n - 2 or any(a >= 0 or b < 0 for a, b in nodes):
        raise ValueError(f"Invalid common negative mesh at n={n}")
    if any((a << d) <= (c << b) for (a, b), (c, d) in zip(nodes, nodes[1:])):
        raise ValueError(f"Common nodes out of order at n={n}")
    for k in methods["representatives"](n):
        if k == 2 and n >= 4:
            continue
        row = methods["trim"](methods["ordinary_row"](n, counts[n,k]))
        for i, node in enumerate(nodes, 2):
            expected = -1 if i % 2 == 0 else 1
            actual = methods["sign_at"](row,node)
            if actual != expected:
                nonalternating.append((n,k,i,expected,actual))
            checked += 1
print(f"Exact shared-grid signs: {checked} evaluations.")
print(f"Failed expected signs: {len(nonalternating)}.")
if nonalternating:
    print("First failures (n,k,i,expected,actual)",nonalternating[:12])
    print("Most common failing (n,k)",Counter((n,k) for n,k,*_ in nonalternating).most_common(12))
    raise SystemExit(1)
else:
    print("All adjacent interior angle brackets shared by all cutoff rows at each n, except the n=5 factor.")
